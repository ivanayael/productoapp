var mongoose = require('mongoose'),
	Schema = mongoose.Schema;

var productoSchema = new Schema({
	nombre: 		{ type: String },
	vencimiento: 		{ type: String },
	pais: 	{ type: String },
	img:  	{ type: String },
	categoria: 		{ type: String, enum :
					['congelados', 'lacteos', 'escolar', 'granja', 'almacen']
				},
	descripcion: 	{ type: String }    
});


module.exports = mongoose.model('producto', productoSchema);