import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { productosService } from '../../services/productos.service';

@Component({
  selector: 'app-producto',
  templateUrl: './producto.component.html'
})

export class productoComponent {

  producto:Object = {
      nombre: null,
      vencimiento: null,
      pais: null,
      img: null,
      categoria: null,
      descripcion: null
  };

  constructor( private activatedRoute:ActivatedRoute,
               private _productosService: productosService
  ) {
    this.activatedRoute.params.subscribe( params => {
      this.activatedRoute.params.subscribe( params => {
      console.log(params['id']);
      this._productosService.getproducto(params['id'])
      .subscribe((data) => this.producto = {
        nombre: data['nombre'],
        vencimiento: data['vencimiento'],
        pais: data['pais'],
        img: data['img'],
        categoria: data['categoria'],
        descripcion: data['descripcion']
      });
    });
  })  
}  
}
