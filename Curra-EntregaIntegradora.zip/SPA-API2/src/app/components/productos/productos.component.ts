import { Component, OnInit } from '@angular/core';
import { productosService } from '../../services/productos.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-productos',
  templateUrl: './productos.component.html'
})

export class productosComponent implements OnInit {

  productos:any[]=[];

  constructor(public _productosService:productosService,
              private router:Router ) { }

  ngOnInit() {
    this._productosService.getproductos().subscribe(data => {
      console.log(data);
      this.productos = data;
    });

  }

  verproducto(idx:number){
    this.router.navigate(['/producto',idx])
    //console.log(idx);
  }

  addproducto(){
    this.router.navigate(['/productos','add'])
  }

  delproducto(id:string){
    this.router.navigate(['/productos','del',id])
  }

  updateproducto(id:string){
    this.router.navigate(['/productos','update',id])
  }

}
