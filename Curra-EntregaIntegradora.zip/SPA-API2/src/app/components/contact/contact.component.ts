/* import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormArray } from '@angular/forms';
import { MessageService } from '../../services/email.service';

//import swal from 'sweetalert';
//estas tres lineas reemplazan la anterior sino da error al ejecutar
import * as _swal from 'sweetalert';
import { SweetAlert } from 'sweetalert/typings/core';
const swal: SweetAlert = _swal as any;


@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styles: []
})
export class ContactComponent {

  forma:FormGroup;

  usuario:Object = {
    nombre: "Ivana",
    apellido: "Curra",
    correo: "ivanayael@hotmail.com",
    consulta: ['Nuevo Producto']
  }


  constructor(public _MessageService: MessageService) {

    this.forma = new FormGroup({
      'nombre': new FormControl('' ,  [ Validators.required,  Validators.minLength(5) ]),
      'apellido': new FormControl('',   Validators.required ),
      'correo': new FormControl('', [Validators.required, Validators.pattern("[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$")]),
      'consulta' : new FormArray([
        new FormControl ('' , Validators.required )
      ])
    })

    this.forma.setValue(this.usuario)

   }
   

   agregarConsulta(){
    (<FormArray>this.forma.controls['consulta']).push(
      new FormControl('', Validators.required)
    )
  }

   guardarCambios(){
    this._MessageService.sendMessage(this.forma).subscribe(() => {
      swal("Formulario de contacto", "Mensaje enviado correctamente", 'success');
    });

     this.forma.reset({
       'nombre' : "",
       'apellido' : "",
       'correo' : ""
     });
   }

}
*/

import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormArray } from '@angular/forms';
import { MessageService } from '../../services/email.service';


//import swal from 'sweetalert';
//estas tres lineas reemlazan la anterior sino da error al ejecutar
import * as _swal from 'sweetalert';
import { SweetAlert } from 'sweetalert/typings/core';
const swal: SweetAlert = _swal as any;

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html'
})

export class ContactComponent {
  constructor(public _MessageService: MessageService) {

  }
  contactForm(form) {
    this._MessageService.sendMessage(form).subscribe(() => {
      swal("Formulario de contacto", "Mensaje enviado correctamente", 'success');
    });
  }
}
