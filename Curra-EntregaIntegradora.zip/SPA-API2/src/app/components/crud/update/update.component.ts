import { Component, OnInit } from '@angular/core';
import { productosService } from '../../../services/productos.service';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html'
})
export class UpdateComponent implements OnInit {

	producto:Object = {
	    _id: null,
      nombre: null,
      vencimiento: null,
	    pais: null,
	    img: null,
	    categoria: null,
	    descripcion: null
	}

  constructor(public _productosService:productosService,
              private activatedRoute:ActivatedRoute,
              private router: Router) { }

  ngOnInit() {
  	this.activatedRoute.params.subscribe( params => {
      console.log(params['id']);
      this._productosService.getproducto(params['id'])
      .subscribe((data) => this.producto = {
        _id: data['_id'],
        nombre: data['nombre'],
        vencimiento: data['vencimiento'],
      	pais: data['pais'],
      	img: data['img'],
      	categoria: data['categoria'],
      	descripcion: data['descripcion']
    });

    });
  }

  modificar(){
    console.log(this.producto);
    this._productosService.updateproducto(this.producto).subscribe(res => {console.log('subscribe'); this.router.navigate(['productos']) });
  }

  cancelar(){
    this.router.navigate(['/productos'])
  }

}
