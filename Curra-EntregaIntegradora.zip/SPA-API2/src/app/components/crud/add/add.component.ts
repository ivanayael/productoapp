import { Component, OnInit } from '@angular/core';
import { productosService } from '../../../services/productos.service';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html'
})
export class AddComponent implements OnInit {

  producto:Object = {
    nombre: null,
    vencimiento: null,
    pais: null,
    img: null,
    categoria: null,
    descripcion: null
  }

  constructor(public _productosService:productosService,
              private router: Router ) { }

  ngOnInit() {

  }

  alta(){
    //console.log(this.producto);
    this._productosService.addproducto(this.producto).subscribe(res => {console.log('subscribe'); this.router.navigate(['productos']) });
  }
  

  cancelar(){
    this.router.navigate(['/productos'])
  }

}
