import { Component, OnInit } from '@angular/core';
import { productosService } from '../../../services/productos.service';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-del',
  templateUrl: './del.component.html'
})

export class DelComponent implements OnInit {

  constructor(public _productosService:productosService,
              private activatedRoute:ActivatedRoute,
              private router:Router ) { }

  ngOnInit() {

    this.activatedRoute.params.subscribe( params => {
      //console.log(params['id']);
      this._productosService.delproducto(params['id']).subscribe();
      //this.router.navigate(['/productos']);
    })

  }


}
