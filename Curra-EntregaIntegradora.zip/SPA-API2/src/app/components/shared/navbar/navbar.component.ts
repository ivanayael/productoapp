import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { productosService } from '../../../services/productos.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html'
})
export class NavbarComponent implements OnInit {

  productos:any[] = [];

  constructor( private _productosService:productosService,
               private router:Router ) {

  }

  ngOnInit()  { this._productosService.getproductos().subscribe(data => {
      console.log(data);
      this.productos = data;
  });

// buscarProducto( terminoBusqueda:string){
 //   this.router.navigate(['/search',terminoBusqueda])
 // }
 
}

}
