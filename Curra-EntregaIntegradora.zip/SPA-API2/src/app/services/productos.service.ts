import { Injectable } from '@angular/core';

import { Observable } from 'rxjs/Observable';
import { HttpClient, HttpHeaders } from "@angular/common/http";
import 'rxjs/add/operator/map';

@Injectable()
export class productosService {

  productos: any[] = [];
  producto: any = {};

  productosUrl: string = 'http://localhost:3000/';

  constructor(public http: HttpClient) { }

  getproductos() {
    return this.http.get(this.productosUrl + 'productos')
    .map( (resp: any) => {
      this.productos = resp;
      return this.productos;
    });
  }


  addproducto (producto) {
    console.log(producto);
    return this.http.post(this.productosUrl + 'producto', producto)
    .map( (resp: any) => {
      this.producto = resp;
      return this.producto;
    });
  }
  

  delproducto(productoid:string) {
    return this.http.delete(this.productosUrl + 'producto/' + productoid);
  }


  getproducto(idx: string){
      
    return this.http.get(this.productosUrl + 'producto/' + idx);
    //console.log(this.producto);
    //return this.producto;
  }

  updateproducto(producto) {
  console.log(producto);
    return this.http.put(this.productosUrl + 'producto/' + producto._id, producto)
    .map( (resp: any) => {
      this.producto = resp;
      return this.producto;
    });
  }
}
