import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

//Rutas
import { APP_ROUTING } from './app.routes';

//Servicios
import { ConectapiService } from './services/conectapi.service';
import { productosService } from './services/productos.service';
import { MessageService } from './services/email.service';

//Componentes
import { AppComponent } from './app.component';
import { NavbarComponent } from './components/shared/navbar/navbar.component';
import { HomeComponent } from './components/home/home.component';
import { AboutComponent } from './components/about/about.component';
import { TemplateComponent } from './components/template/template.component';
import { ContactComponent } from './components/contact/contact.component';
import { ConectapiComponent } from './components/conectapi/conectapi.component';
import { productosComponent } from './components/productos/productos.component';
import { productoComponent } from './components/producto/producto.component';
import { AddComponent } from './components/crud/add/add.component';
import { DelComponent } from './components/crud/del/del.component';
import { UpdateComponent } from './components/crud/update/update.component';


@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    HomeComponent,
    AboutComponent,
    TemplateComponent,
    ContactComponent,
    ConectapiComponent,
    productosComponent,
    productoComponent,
    AddComponent,
    DelComponent,
    UpdateComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    APP_ROUTING
  ],
  providers: [
    ConectapiService,
    productosService,
    MessageService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
