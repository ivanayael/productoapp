import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { AboutComponent } from './components/about/about.component';
import { ConectapiComponent} from './components/conectapi/conectapi.component';
import { productosComponent} from './components/productos/productos.component';
import { productoComponent } from './components/producto/producto.component';
import { AddComponent } from './components/crud/add/add.component';
import { DelComponent } from './components/crud/del/del.component';
import { UpdateComponent } from './components/crud/update/update.component';
import { ContactComponent } from './components/contact/contact.component';


const APP_ROUTES: Routes = [
  { path: 'home', component: HomeComponent },
  { path: 'about', component: AboutComponent },
  { path: 'conectapi', component: ConectapiComponent },
  { path: 'productos', component: productosComponent },
  { path: 'productos/add', component: AddComponent },
  { path: 'productos/del/:id', component: DelComponent },
  { path: 'productos/update/:id', component: UpdateComponent },
  { path: 'producto/:id', component: productoComponent },
  { path: 'contact', component: ContactComponent },
  { path: '**', pathMatch: 'full', redirectTo: 'home' }
];

export const APP_ROUTING = RouterModule.forRoot(APP_ROUTES, { useHash:true } );
